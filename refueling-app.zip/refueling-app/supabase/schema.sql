-- ============================================================
-- SKEMA DATABASE APLIKASI REFUELING & SLA MONITORING
-- Jalankan file ini di: Supabase Dashboard > SQL Editor > New Query > Run
-- ============================================================

-- 1. PROFIL PENGGUNA (admin / fuelman)
create table if not exists profiles (
  id uuid references auth.users(id) primary key,
  full_name text not null,
  role text not null check (role in ('admin','fuelman')) default 'fuelman',
  created_at timestamptz default now()
);

-- 2. FUEL TRUCK (truk pengisian bahan bakar)
create table if not exists fuel_trucks (
  id bigint generated always as identity primary key,
  code text not null unique,      -- contoh: FT-01
  name text,
  is_active boolean default true
);

-- 3. AREA / LOKASI
create table if not exists areas (
  id bigint generated always as identity primary key,
  name text not null unique       -- contoh: Pit A, Pit B, Workshop
);

-- 4. UNIT (alat berat / kendaraan yang perlu di-refuel)
create table if not exists units (
  id bigint generated always as identity primary key,
  unit_no text not null unique,   -- contoh: HD-123
  area_id bigint references areas(id),
  is_active boolean default true
);

-- 5. WORK ORDER (dibuat dari hasil upload Excel, dikelompokkan per area)
create table if not exists work_orders (
  id bigint generated always as identity primary key,
  wo_number text not null unique,     -- contoh: WO-2026-07-15-PITA
  area_id bigint references areas(id),
  shift text,                          -- contoh: Shift 1 / Shift 2
  target_minutes int default 120,      -- target waktu SLA (menit) sejak WO dibuat
  created_by uuid references profiles(id),
  created_at timestamptz default now(),
  status text default 'open' check (status in ('open','closed'))
);

-- 6. ITEM DALAM WORK ORDER (unit-unit yang harus diisi dalam WO tsb)
create table if not exists wo_units (
  id bigint generated always as identity primary key,
  wo_id bigint references work_orders(id) on delete cascade,
  unit_id bigint references units(id),
  status text default 'pending' check (
    status in ('pending','refueling','fuel_aman','unit_bd','jalan_tidak_ready','unit_tidak_reposisi')
  ),
  truck_id bigint references fuel_trucks(id),
  updated_by uuid references profiles(id),
  updated_at timestamptz,
  unique(wo_id, unit_id)
);

-- 7. LOG HISTORY (jejak setiap perubahan status, untuk audit & SLA)
create table if not exists refueling_logs (
  id bigint generated always as identity primary key,
  wo_unit_id bigint references wo_units(id) on delete cascade,
  status text not null,
  truck_id bigint references fuel_trucks(id),
  created_by uuid references profiles(id),
  created_at timestamptz default now()
);

-- Index untuk mempercepat query dashboard
create index if not exists idx_wo_units_wo on wo_units(wo_id);
create index if not exists idx_wo_units_status on wo_units(status);
create index if not exists idx_logs_wo_unit on refueling_logs(wo_unit_id);

-- ============================================================
-- ROW LEVEL SECURITY (supaya fuelman hanya bisa update, admin full akses)
-- ============================================================
alter table wo_units enable row level security;
alter table work_orders enable row level security;

create policy "semua user login bisa lihat wo_units"
  on wo_units for select using (auth.role() = 'authenticated');

create policy "semua user login bisa update wo_units"
  on wo_units for update using (auth.role() = 'authenticated');

create policy "semua user login bisa lihat work_orders"
  on work_orders for select using (auth.role() = 'authenticated');
